    function toggleToolbox() {
        const toolsContainer = document.getElementById("shapebox");
        if (shapebox.style.display === "none" || shapebox.style.display === "") {
            shapebox.style.display = "grid";  // Show tools
        } else {
            shapebox.style.display = "none"; // Hide tools
        }
}

function toggleToolbox2() {
    const toolsContainer2 = document.getElementById("shapebox2");
    if (shapebox.style.display === "none" || shapebox.style.display === "") {
        shapebox.style.display = "grid";  // Show tools
    } else {
        shapebox.style.display = "none"; // Hide tools
    }
}